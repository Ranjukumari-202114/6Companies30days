/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/


//1025. Divisor Game



class Solution {
    public boolean divisorGame(int n) {
      
     if(n%2==1)
     {
         return false;
     } 
     return true;   
    }
  
}
